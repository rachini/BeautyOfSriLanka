<?php

/**
 * Allows custom session handling
 * by replacing simple session_start() with custom session functions
 */
session_start();

?>