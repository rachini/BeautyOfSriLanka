
----------------------------------
        p.mapper README
----------------------------------

See 

* quick install instructions:
  http://svn.pmapper.net/trac/wiki/DocQuickinstall

* main documentation (manual):
  http://svn.pmapper.net/trac/wiki/DocManual

* acknowledgements: 
  http://svn.pmapper.net/trac/wiki/AcknowedgeMents

* change log: 
  http://svn.pmapper.net/trac/wiki/ChangeLog


See license.txt for p.mapper license
