<?php

$_SESSION['queryeditor_activated'] = true;

?>