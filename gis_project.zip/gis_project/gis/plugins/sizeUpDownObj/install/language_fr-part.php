<?php

// sizeUpDownObj
$_sl['sizeUpDownObj__size_up'] = 'Augmenter la taille des objets';
$_sl['sizeUpDownObj__size_down'] = 'R�duire la taille des objets';
$_sl['sizeUpDownObj__size_reset'] = 'R�initialiser la taille des objets';
$_sl['sizeUpDownObj__size_resetall'] = 'R�initialiser la taille de tous les niveaux';
$_sl['sizeUpDownObj__ret_1'] = 'La limite d\'agrandissement est atteinte.';
$_sl['sizeUpDownObj__ret_2'] = 'La limite de diminution est atteinte.';
$_sl['sizeUpDownObj__Caption'] = 'Modification de la taille des objets.';

?>