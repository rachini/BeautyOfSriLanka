<?php

// measure2 and drawing:
$_sl['Color'] = 'Couleur';
$_sl['Delete'] = 'Supprimer';
$_sl['Type'] = 'Type';
$_sl['Empty'] = 'Vider';

// Measure2
$_sl['Measure2'] = 'Mesure';
$_sl['Number'] = 'Num�ro';
$_sl['Distance'] = 'Distance';
$_sl['cat_measure'] = 'Mesures g�om�triques';
$_sl['Measure'] = 'Mesure';
$_sl['Area'] = 'Surface';

?>