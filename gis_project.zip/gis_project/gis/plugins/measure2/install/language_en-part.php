<?php

// measure2 and drawing:
$_sl['Color'] = 'Color';
$_sl['Delete'] = 'Delete';
$_sl['Type'] = 'Type';
$_sl['Empty'] = 'Remove all';

// Measure2
$_sl['Measure2'] = 'Measure';
$_sl['Number'] = 'Number';
$_sl['Distance'] = 'Distance';
$_sl['cat_measure'] = 'Measures';
$_sl['Measure'] = 'Measure';
$_sl['Area'] = 'Area';

?>