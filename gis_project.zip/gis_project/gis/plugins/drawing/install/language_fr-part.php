<?php

// measure2 and drawing:
$_sl['Color'] = 'Couleur';
$_sl['Delete'] = 'Supprimer';
$_sl['Type'] = 'Type';
$_sl['Empty'] = 'Vider';

// drawing:
$_sl['drawing_help'] = 'Un clic pour commencer, double-clic pour finir le dessin.<br />Supprimer le dernier point avec la touche �SUPPR�.';
$_sl['Point'] = 'Point';
$_sl['Line'] = 'Ligne';
$_sl['Polygon'] = 'Polygone';
$_sl['Circle'] = 'Cercle';
$_sl['Index'] = 'Indice';
$_sl['Comment'] = 'Commentaire';
$_sl['Add comment:'] = 'Ajouter un commentaire :';
$_sl['Outline'] = 'Contour';
$_sl['dblclick_error'] = 'un simple clic suffit pour dessiner';
$_sl['Drawing'] = 'Dessin';
$_sl['cat_drawing'] = 'Dessins';
$_sl['Rectangle'] = 'Rectangle';
$_sl['Annotation'] = 'Annotation';
$_sl['Radius'] = 'Rayon';
$_sl['Circumference'] = 'Circonf�rence';
$_sl['Area'] = 'Superficie';

?>