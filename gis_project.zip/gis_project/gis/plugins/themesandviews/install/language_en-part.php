<?php

// TAV :
$_sl['Apply theme'] = 'Apply theme';
$_sl['Apply view'] = 'Apply view';

?>