DHTML scalebar based on a library from 
Tim Schaub of CommEn Space (http://www.commenspace.org)

Requires 2 DIV's in the map.phtml, like
    <div id="scaleReference">
        <div id="scalebar"></div>
    </div>

Style of the scalebar can be defined via CSS file in config.inc 
