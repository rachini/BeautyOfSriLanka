Proj4js.defs["EPSG:27200"] = "+title=New Zealand Map Grid\
  +proj=nzmg \
  +lat_0=-41 +lon_0=173 \
  +x_0=2510000 +y_0=6023150 \
  +ellps=intl +datum=nzgd49 +units=m +no_defs"
